-==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==--==----==--==----==--==----==--==----==--==----==--==-
Hello & welcome to dx9's ROBLOX cheat.
This is the Alpha version so it'll include some bugs which you are encouraged to report to the discord server stated below.
<https://discord.gg/vp8THwJ>


RUN INIT_RUNONCE ONLY ONCE, NEVER AGAIN.
TO ROLLBACK FROM INITIALISATION REINSTALL/UPDATE ROBLOX.
IF IT SAYS AN ERROR ABOUT SDK DOWNLOAD WHAT IT SAYS.

Controls:
F1- Toggle/disable gui 
note : you can toggle your cheat and disable the menu so that the double cursor is not present.

How do I report a bug?: 
Simply post what cheat you had toggled and post a message tagging dx9 in `report-bugs` channel.

I crashed?:
This cheat is in ALPHA stage, crashes are rare but could happen. Please do the same as bug subsection.